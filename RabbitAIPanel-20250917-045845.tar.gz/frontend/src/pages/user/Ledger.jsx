import React, { useEffect, useState } from 'react'
import { getLedger } from '../../utils/api'
import Container from '../../primer/Container'
import Button from '../../primer/Button'
import { currentUserId } from '../../utils/dev'

export default function Ledger() {
  const [userId, setUserId] = useState(currentUserId('1'))
  const [entries, setEntries] = useState(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')
  // 移除高级/用户ID修改入口
  const load = async (overrideUid) => {
    setLoading(true); setErr('')
    const uid = (overrideUid ?? userId)
    try { const res = await getLedger(Number(uid)); setEntries(res.entries || []) } catch (e) { setErr(String(e)) } finally { setLoading(false) }
  }
  useEffect(() => {
    // 初始自动加载
    load()
    const syncAndLoad = () => {
      const uid = currentUserId('1')
      if (uid !== userId) setUserId(uid)
      load(uid)
    }
    window.addEventListener('rr:settings-saved', syncAndLoad)
    window.addEventListener('focus', syncAndLoad)
    return () => {
      window.removeEventListener('rr:settings-saved', syncAndLoad)
      window.removeEventListener('focus', syncAndLoad)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  return (
    <Container>
      {/* 标题移除 */}
      <div className="mt-4 grid grid-cols-1 md:grid-cols-1 gap-3">
        <Button onClick={load} color="blue">刷新</Button>
      </div>
      {loading && <div className="text-sm text-gray-500">加载中…</div>}
      {err && <div className="text-sm text-red-600">{err}</div>}
      {entries && (
        <div className="rr-table-flow mt-4">
          <div className="rr-table-scroll">
            <div className="rr-table-inner">
              <table className="rr-table">
                <thead>
                  <tr>
                    <th scope="col">created_at</th>
                    <th scope="col">currency</th>
                    <th scope="col">amount_cents</th>
                    <th scope="col">reason</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((l,i)=>(
                    <tr key={i}>
                      <td>{l.created_at}</td>
                      <td>{l.currency}</td>
                      <td>{l.amount_cents}</td>
                      <td>{l.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </Container>
  )
}
