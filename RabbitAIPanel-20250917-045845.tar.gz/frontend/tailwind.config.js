// Tailwind CSS v4 uses CSS-first configuration via @theme in your CSS.
// This JS config is no longer required, kept empty to avoid confusion.
export default {}
