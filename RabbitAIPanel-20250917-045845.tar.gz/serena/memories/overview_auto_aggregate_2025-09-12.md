Overview page now aggregates multiple modules with auto-load and robust error handling.

- File: frontend/src/pages/user/Overview.jsx
- Imports: added getDailyReport, getSummaryReport, getOverdraftReport, getPeriod.
- States: added period/daily/summary/overdraft data + loading + error states; default dateTo=today, dateFrom=today-6 days; sumDays=7; odDays=7.
- Loaders: loadBudget, loadPeriod, loadDaily, loadSummary, loadOverdraft; loadAll triggers all in parallel (independent state and try/catch per module).
- Effects: on mount and on rr:settings-saved/window focus, call loadAll; sync userId from currentUserId('1').
- UI: Added sections for period summary, today daily, overdraft count, and a summary table; button renamed to “刷新全部”.

User pages (Wallets/Ledger/Period/Daily/Summary/Overdraft) already auto-load and refresh on events per previous memory entry.