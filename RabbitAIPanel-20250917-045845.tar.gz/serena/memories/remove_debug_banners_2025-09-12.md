Removed production-facing DEBUG banners.

- DevSettingsModal: removed warning banner shown when VITE_DEBUG is off.
- Other debug UI remains gated (API indicator, gear, warnings) and does not render without VITE_DEBUG.

Outcome: No debug hints surface to end-users in production.