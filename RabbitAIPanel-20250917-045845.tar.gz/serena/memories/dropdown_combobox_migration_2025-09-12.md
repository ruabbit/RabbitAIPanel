Converted native <select> elements to a custom combobox-style Select component across the app.

- New component: frontend/src/components/Select.jsx (chevron indicator, dropdown panel, click-outside close). Uses react-icons FiChevronDown. Props: id, value, onChange, options, placeholder.
- Updated pages:
  - User: Period (group_by) now uses Select.
  - Admin: TeamPeriod (group_by), PlanCreate (type), PlanDaily (overflow_policy), PlanUsage (billing_cycle), PlanAssign (entity_type), Customers (entity_type), PriceMappings (active) and legacy Admin aggregator (pmActive, assEntityType, tpGroup).
- Rationale: original selects looked identical to inputs; the combobox-style control improves affordance per example/input/comboboxes guidance, without adding headlessui dependency.

Next: if needed, add keyboard navigation and ARIA-enhancements to Select, or replace with @headlessui/react if dependencies allowed.