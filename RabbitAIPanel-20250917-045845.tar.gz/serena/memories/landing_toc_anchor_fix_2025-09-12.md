Fixed the landing TableOfContents anchor links.

- File: frontend/src/primer/TableOfContents.jsx
- Problem: hrefs were generated from Chinese titles (e.g., #功能概览) and didn’t match section IDs.
- Fix: Each item now has explicit hrefs mapping to real section IDs: #introduction, #screencasts, #resources, #pricing, #author.
- NavBarPrimer already used correct ids; now in-content TOC links are consistent and scroll correctly.