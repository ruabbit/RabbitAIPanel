# Next Steps Update 5 (2025-09-03)

- Implemented:
  - Outbox + retry worker for HTTP events (resilience), integrated in Lago stub fallback.
  - Billing scaffolding: Customer, Subscription, Invoice/InvoiceItem models + API (create and generate invoice from usage).
  - Overdraft gating + configurable degrade mapping completed.

- Docs updated: api.md (billing section), billing_and_lago.md (roadmap and resilience).

- Next focus: Integrate Stripe Billing (Customer/Subscription/Invoice flows) with idempotency + retries, and add rate-limiting + secrets management improvements.
