Removed SectionHeading titles (e.g., U1|概览, A1|计划) from panel pages with left navigation.

- Rationale: Panel uses AppFrame with sidebar; per-page title banners are redundant and intended only for landing/sticky multi-section pages.
- Affected files (imports and nodes removed):
  - User: Overview.jsx, Period.jsx, Daily.jsx, Summary.jsx, Overdraft.jsx, Wallets.jsx, Ledger.jsx, Proxy.jsx
  - Admin: PlanCreate.jsx, PlanDaily.jsx, PlanUsage.jsx, PlanPriceRule.jsx, PlanAssign.jsx, PlanDetail.jsx, PriceMappings.jsx, Customers.jsx, Subscriptions.jsx, Invoices.jsx, TeamPeriod.jsx, StripeEnsure.jsx
- Kept: PrimerPreview.jsx retains SectionHeading for component preview context.

Outcome: Cleaner panel pages with consistent Application UI layout; functionality unchanged.