Ported Primer-like landing components and integrated routes.
- Added components under src/primer: Container, Button, GridPattern, SectionHeading, CheckIcon, StarRating, Hero, Introduction, Pricing, FooterPrim, NavBarPrimer (no headlessui dependency).
- Added pages: PrimerHome (as new / index) and PrimerPreview (/primer/preview).
- Layout hides default Navbar/Footer on primer routes.
- Added font links (Cabinet Grotesk via fontshare, Inter via Google) in index.html.
- Extended Tailwind v4 @theme tokens to include primer-like shadows, radii, text sizes, and display font.
Commit: 01069e6 on main.