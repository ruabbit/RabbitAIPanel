Migrated /dashboard and /admin to Tailwind Application UI-style frame.
- Added AppFrame (mobile drawer + desktop sidebar, sticky topbar, content wrapper).
- Replaced UserLayout/AdminLayout to use AppFrame; preserved routes and content; still leveraging Primer Button/Container/SectionHeading inside pages.
- Icons via react-icons (Feather-inspired) instead of Heroicons to avoid new deps.
Commit: fd26d9b on main.