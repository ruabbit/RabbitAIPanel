Migrated input/select/textarea styles across user + admin pages using example/input patterns.

- CSS: Added in frontend/src/index.css
  - rr-label: label typography
  - rr-input: input baseline (rounded-md, outline-1, focus:outline-2, spacing)
  - rr-select: styled select (appearance-none, pr-8, shared focus styles)
  - rr-textarea: textarea baseline (mirrors rr-input)

- Updated pages to add proper labels and swap classes to rr-*:
  - User: Period (date_from/to, group_by), Daily (date), Summary (days), Overdraft (days), Proxy (model, x-litellm-api-key, prompt)
  - Admin: TeamPeriod (team_id, date_from/to, group_by), Invoices (customer_id, date_from/to, invoice_id, query id), Subscriptions (create/list/query fields), PriceMappings (list filter, create, update/delete), PlanCreate, PlanDaily, PlanUsage, PlanAssign, PlanDetail, Customers, plus Admin aggregators replaced border inputs with rr-*.

- Kept previous auto-load + error handling intact.

Next: if desired, add a Chevron icon overlay for rr-selects (like example/input_shared_borders), or extract a reusable <Field> wrapper for label+control spacing.