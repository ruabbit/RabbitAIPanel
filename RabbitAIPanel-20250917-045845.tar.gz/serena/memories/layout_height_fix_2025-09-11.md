Layout height fix:
- Root Layout container changed from `min-h-screen` to `h-screen` (definite height), enabling percentage heights to resolve for children.
- User/Admin grid wrappers switched from `min-h-full` to `h-full` so the sidebar `<aside h-full>` fills available column height at >=md.
- Maintains `main.flex-1 min-h-0` for proper nested scrolling.
Commit: 42e67ea on main.