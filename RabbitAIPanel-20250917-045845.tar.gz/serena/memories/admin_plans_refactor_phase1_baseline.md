Admin plans refactor Phase 1 baseline:
- Navigation: Admin sidebar now shows only Plans (/admin/plans), Customers, Subscriptions, Invoices, Team Period. All old plan subpages (plan/create, plan/daily, plan/usage, plan/pricerule, plan/assign, price-mappings, stripe-ensure) are removed from the menu but legacy routes remain accessible for fallback.
- New routes/components:
  - /admin/plans -> src/pages/admin/plans/PlansList.jsx (entry; open PlanDetail by plan_id).
  - /admin/plans/:planId -> src/pages/admin/plans/PlanDetail.jsx (tabs: Overview, Pricing [rules + mappings], Limits, Usage Plan, Assignments, Danger [Stripe ensures]).
- Main route file updated: src/main.jsx includes new routes while keeping legacy routes for backward compatibility during transition.
- Existing forms migrated into PlanDetail tabs; behaviors preserved using utils/api.js.
- Build verified OK after refactor.