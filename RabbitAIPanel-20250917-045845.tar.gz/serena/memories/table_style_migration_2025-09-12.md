Migrated table styling across user and admin pages to match example/table.

- CSS: Added rr-table, rr-table-flow, rr-table-scroll, rr-table-inner classes in frontend/src/index.css using Tailwind @apply to reflect the example’s spacing, dividers, and responsive wrappers.
- User pages updated to rr-table + wrappers:
  - Overview: summary table.
  - Period: dynamic group-by table.
  - Summary: daily summary table.
  - Overdraft: overdraft events table.
  - Ledger: ledger entries table.
- Admin pages updated:
  - Subscriptions.jsx, Invoices.jsx, PriceMappings.jsx use rr-table and wrappers.
  - Admin.jsx legacy demo page updated in all table sections (subscriptions, invoices, price mappings, ledger).
- Old border+bg-gray-100 grid styles removed; headers now use example-like th spacing and colors. Body rows use divide-y with neutral text tone.
- Existing data fetching and error handling unchanged; only view-level table markup updated.

Next: If needed, create a reusable <Table> component in primer/ for future tables to reduce duplication.