# 常用命令与环境

- 环境准备（Python 3.10+）：
  - 安装依赖（最小集）：
    - `pip install sqlalchemy pydantic stripe`
    - API 服务：`pip install fastapi uvicorn`
  - 可选环境变量：
    - Stripe: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PUBLISHABLE_KEY`
    - Dev 认证：`DEV_API_KEY`
    - Lago: `LAGO_API_URL`, `LAGO_API_KEY`
    - LiteLLM: `LITELLM_BASE_URL`, `LITELLM_MASTER_KEY`, `LITELLM_BUDGET_DURATION`

- 初始化数据库（SQLite）：
  - Python REPL：
    ```py
    from middleware.db import init_db
    init_db()
    ```

- 启动 API：
  - `uvicorn api.server:app --reload`
  - 健康检查：`curl http://localhost:8000/healthz`

- Stripe Payment Element 演示页：
  - 打开：`http://localhost:8000/demo/payment_element?api=http://localhost:8000&pk=$STRIPE_PUBLISHABLE_KEY&key=$DEV_API_KEY`

- 创建充值（示例 curl）：
  - `curl -H "x-api-key: $DEV_API_KEY" -H "Content-Type: application/json" -d '{"user_id":1,"amount_cents":1000,"currency":"USD"}' http://localhost:8000/v1/payments/checkout`

- 开发小贴士：
  - 未配置 Stripe/Lago/LiteLLM 时，相关调用为 best-effort/no-op。
  - Webhook：`POST /v1/webhooks/stripe`（Stripe 签名校验通过 `STRIPE_WEBHOOK_SECRET` 控制）。
