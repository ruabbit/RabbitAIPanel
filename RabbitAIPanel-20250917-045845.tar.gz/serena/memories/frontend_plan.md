Frontend scaffold (React+Vite+Tailwind)
- Structure: frontend/ with shared Layout (Navbar+Footer), pages Home/Dashboard/Admin, AuthCallback fallback
- Navbar includes dev config modal (DEV_API_KEY, x-dev-user-id, provider) and Social Login button
- API utils: startSocialLogin -> POST /v1/auth/social/start; syncProfile -> POST /v1/auth/sync_profile
- Next: add real branding/content, dashboards wiring (wallets/reports/billing), auth-bound redirects once Logto credentials and connectors provided
