Auth/Logto integration (demo-phase)

- Goal: Disable public registration in Logto, keep social sign-up/login via our system. Use temp_ user pre-creation, then bind social identity and backfill profile.
- Implemented (skeleton):
  - Configs: LOGTO_ENDPOINT, LOGTO_CLIENT_ID/SECRET, LOGTO_REDIRECT_URI, LOGTO_MGMT_CLIENT_ID/SECRET, LOGTO_MGMT_RESOURCE, CONNECTOR_* IDs.
  - Management API wrapper: client_credentials token; create_temp_user; user profile update helpers; placeholder bind_social_identity (expects verification id).
  - Routes:
    - POST /v1/auth/social/start: create temp_ user, return OIDC authorize URL + state.
    - GET /auth/social/callback: validate state, redirect to OIDC sign-in (binding will be completed in next iteration).
  - Docs: Added Auth(Logto) section with flow, configs, and next steps.
- Next after demo:
  - Implement connector verification flow to obtain verification_record_id; call Management API to bind identity to temp_ user; backfill email/name/avatar; rename username to email; conflict resolution and cleanup failed temp_ accounts.
  - Optional: invitation-only links, organization roles assignment post-binding.
