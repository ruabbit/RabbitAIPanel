Added `example/` to .gitignore to exclude local Tailwind Plus Primer templates from version control.
Commit: 09d8f20 on main.