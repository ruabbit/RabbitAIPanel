# 任务完成后检查清单

- 运行静态检查/格式化（如果项目已配置）：例如 `ruff`, `black`（当前仓库未内置配置，可按团队规范使用）。
- 初始化并启动 API：`init_db()` -> `uvicorn api.server:app --reload` -> `GET /healthz`。
- 基本回归验证：
  - `POST /v1/payments/checkout` 正常返回（未配置 Stripe 时可能报错）。
  - 若配置了 Stripe：`/v1/webhooks/stripe` 能处理 `payment_intent.succeeded` 并写入钱包流水。
  - 钱包接口：`GET /v1/wallets/{user_id}`、`GET /v1/wallets/{user_id}/ledger`。
- 环境检查：必要的环境变量（Stripe/Lago/LiteLLM/dev key）是否设置正确。
- 文档同步：如有接口/行为变更，更新 `docs/api.md` 与 `README.md`。