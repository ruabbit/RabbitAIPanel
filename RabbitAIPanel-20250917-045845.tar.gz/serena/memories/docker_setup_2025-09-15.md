Docker setup (2025-09-15)
- Added Dockerfile.backend (Python 3.11 slim, installs requirements, runs uvicorn api.server:app on 8000, default DATABASE_URL sqlite:////data/dev.db)
- Added Dockerfile.frontend (Node 20 alpine, npm ci + build, runs vite preview on 5173; supports build-arg VITE_API_BASE)
- Added docker-compose.yml with services:
  - api: ports 8000:8000, env DATABASE_URL sqlite:////data/dev.db, DEV_API_KEY dev-secret, volume api_data:/data
  - web: build arg VITE_API_BASE http://localhost:8000, depends_on api, ports 5173:5173
- Added .dockerignore for caches, node_modules, dist, git, etc.
- README updated with Docker usage and notes.