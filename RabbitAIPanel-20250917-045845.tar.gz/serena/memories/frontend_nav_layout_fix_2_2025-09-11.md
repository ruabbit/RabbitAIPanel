UI layout fixes per feedback:
- Header/Footer: dropped Tailwind `container`; now full-width with `w-full px-4` to avoid ~125px symmetric margins around ~md widths.
- Sidebar (desktop): always rendered; display toggled with Tailwind (`hidden md:block` when open, `hidden md:hidden` when closed). No element removal for visibility.
- Sidebar height: `Layout` main set to `min-h-0`; user/admin grids use `min-h-full` so `<aside h-full>` fills available height.
- Mobile overlay unchanged.
Commit: 0c51c92 on main.