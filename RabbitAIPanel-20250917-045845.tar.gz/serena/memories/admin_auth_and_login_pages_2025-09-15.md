Admin auth + login pages (2025-09-15)
- Backend: Added admin_auth dependency using ADMIN_AUTH_TOKEN (DB) via x-admin-auth; debug fallback via dev-auth; added /v1/admin/ping; protected /v1/settings (GET/keys/PATCH), /v1/plans, /v1/billing, /v1/teams, and reports /period_team.
- Settings: ADMIN_AUTH_TOKEN registered as sensitive (hidden), PATCH restricted to debug mode only.
- Frontend: Added /login (user), /admin/login (admin token), /purchase (Stripe demo link). API injects x-admin-auth from localStorage; AdminLayout guards with /v1/admin/ping. Logout clears dev_user_id/dev_api_key/admin_auth_token.
- Notes: In non-debug, missing config yields generic errors; debug shows flow demos without exposing secrets.