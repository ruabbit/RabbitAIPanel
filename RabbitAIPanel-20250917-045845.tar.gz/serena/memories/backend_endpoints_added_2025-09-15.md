Backend updated:
- Plans: add GET /v1/plans with (q, type, limit, offset). Implemented list_plans() in middleware/plans/service.py.
- Billing: add GET /v1/billing/customers with (entity_type, entity_id, limit, offset). Implemented list_customers() in middleware/billing/service.py.
- Existing: GET /v1/billing/invoices, GET /v1/billing/subscriptions present; GET /v1/reports/period_team present.
Notes: Endpoints use dev_auth; if DEV_API_KEY is set, requests must include x-api-key. 