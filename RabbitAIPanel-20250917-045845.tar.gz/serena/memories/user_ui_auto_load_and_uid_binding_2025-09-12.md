User-side UI improvements:

- API base override: utils/api.js now resolves API base per-call via apiBase() (localStorage.api_base > VITE_API_BASE). Exported currentApiBase() for UI display. Added dev-time console warn if base unresolved.
- Visual hints: Navbar and AppFrame show current API and display a yellow warning banner when unset. Added lightweight toast util for configuration saves.
- DevSettingsModal: Saving now trims API base, clears override when empty, shows toast, and dispatches custom event `rr:settings-saved`.
- User pages auto-load: Overview, Wallets, Ledger, Period, Daily, Summary, Overdraft now auto-load on mount and on `rr:settings-saved`/window focus; they also synchronize `userId` from `currentUserId('1')`. The manual UID input remains behind an Advanced toggle, and buttons renamed to “刷新”.
- Proxy page remains manual (send request) and displays current user id only.

Next: Admin-side: assess read/query UIs vs backend capabilities before implementing query views.