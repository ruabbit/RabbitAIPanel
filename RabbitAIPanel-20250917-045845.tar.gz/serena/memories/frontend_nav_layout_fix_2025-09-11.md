Frontend fixes: 
- Made sidebar toggleable across all breakpoints; desktop can now hide/show via the same menu button. 
- Navbar menu button shows on all widths (removed md:hidden). 
- Sidebar desktop visibility now depends on UIContext.sidebarOpen; mobile overlay unchanged. 
- AdminLayout/UserLayout grids collapse to single column when sidebar is closed; removed arbitrary min-h that caused odd bottom spacing on wide screens. 
- React icons remain via react-icons (FiMenu, FiSettings, FiLogIn, etc.). 
Commit: 35ef0ea on main.