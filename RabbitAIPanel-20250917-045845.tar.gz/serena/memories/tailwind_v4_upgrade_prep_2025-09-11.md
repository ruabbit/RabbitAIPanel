Prepared Tailwind v4 upgrade while keeping Vite + React Router.
- package.json: tailwindcss ^4.1.11, added @tailwindcss/postcss ^4.1.11.
- postcss.config.js: switch plugin to '@tailwindcss/postcss' (keep autoprefixer).
- src/index.css: use @import "tailwindcss" and define @theme tokens for --color-primary and --color-primary-dark.
- tailwind.config.js: replaced with empty export (v4 uses CSS-first config).
Note: Requires running package install locally.
Commit: 10f66cc on main.