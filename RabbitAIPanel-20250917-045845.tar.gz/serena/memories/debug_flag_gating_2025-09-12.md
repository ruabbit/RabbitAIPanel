Added VITE_DEBUG gating for frontend dev features and auth button.

- dev.js: new isDebug() parses VITE_DEBUG, isLogged() best-effort cookie check; currentUserId/currentApiKey/currentProvider now only use localStorage when debug=true.
- api.js: getApiBase uses localStorage api_base only when debug=true; headers include x-api-key/x-dev-user-id only when debug=true; env VITE_API_BASE remains the baseline.
- DevSettingsModal: shows a banner when debug=false that settings won’t take effect.
- Navbar/AppFrame: hide API base indicator and configuration gear unless debug=true; social login hidden when logged, shown always in debug with label "社交登录测试"; API unset yellow banner shown only in debug.

Outcome: Production UI is clean; dev overrides are inert without VITE_DEBUG; debug sessions expose tooling explicitly.