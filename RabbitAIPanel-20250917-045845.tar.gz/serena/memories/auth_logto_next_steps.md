After demo: implement full social binding in callback
- Require verification_record_id + connector_target_id from Logto social verification flow
- On callback: bind identity to temp_ user; fetch userinfo via OIDC tokens; set primaryEmail, update profile, rename username if temp_
- Handle conflicts: if email belongs to existing non-temp user, merge/bind into existing and delete/soft-archive temp_
- Temp user cleanup: expire after 24h if not bound; background job to sweep
- Front-end: finalize redirect target post-auth; optionally store claims
