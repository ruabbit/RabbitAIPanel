# 代码风格与约定

- 语言/栈：Python 3.10+，FastAPI，Pydantic，SQLAlchemy 2.x ORM，SQLite 默认存储；Stripe SDK 可选。
- 类型：广泛使用类型注解（typing/Protocol、pydantic.BaseModel、sqlalchemy.orm.Mapped）。
- 命名：Python 常规 snake_case；模型/类采用驼峰；表名为复数英文小写（如 `orders`）。
- 配置：集中于 `middleware/config.py`（dataclass Settings 从环境变量读取）。
- API：FastAPI 路由位于 `api/`，请求体使用 Pydantic 模型；开发鉴权使用 `x-api-key`；CORS 在启动时统一配置。
- 数据层：`middleware/db.py` 初始化引擎与 `init_db()`；`middleware/models.py` 定义 ORM 模型；钱包/流水在 `middleware/wallets.py`。
- 支付框架：`middleware/payments/`，Provider 采用 Protocol 约束，实际 Provider 独立实现（如 Stripe）。
- 集成外部服务：`middleware/integrations/` 提供简化 stub，失败为容错（不抛致命异常）。
- 日志：FastAPI 启动中设置基础 logging；实际生产建议使用结构化日志与中间件。
