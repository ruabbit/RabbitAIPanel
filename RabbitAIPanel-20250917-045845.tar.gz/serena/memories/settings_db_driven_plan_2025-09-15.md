Settings refactor baseline (2025-09-15)

Principles
- Env-only: DATABASE_URL (default sqlite:///./dev.db), DEV_API_KEY
- DB-first: all other configs move to DB `settings` (fallback to env; STRICT_DB_MODE=1 disables fallback)
- Runtime reload: PATCH /v1/settings clears in-process cache for immediate effect

Backend
- runtime_config.py: get(key,type,default), clear_cache(), is_sensitive, is_protected
- Protected env keys: {DATABASE_URL, DEV_API_KEY}
- Sensitive keys: Stripe secrets, Lago API key, LiteLLM master key, Logto client secrets
- /v1/settings (GET/PATCH) now masks sensitive values; PATCH clears cache
- /v1/settings/keys (GET): returns metadata list + grouped map (payments, lago, litellm, auth, rate_limit, overdraft, other)
- All modules switched to DB-first reads via runtime_config: Stripe, Lago, LiteLLM, Logto/OIDC, rate limit, degrade mapping

Frontend
- Admin Settings page grouped by metadata; sensitive fields marked and not echoed after save
- Left-bottom Settings link routes fixed: admin -> /admin/settings, user -> /settings

Docs
- README updated: Configuration Model section summarizing DB-first approach and endpoints