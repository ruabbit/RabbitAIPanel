Docs & README updated (2025-09-15)
- README: Added Deployment section with A) Direct deploy and B) Docker deploy; clarified DB-first runtime settings and env-only keys.
- docs/deploy.md: Consolidated into dual-path guide (A: Python+Node direct deploy, B: Docker Compose). Includes backend venv setup, frontend VITE_API_BASE, docker compose steps, customization notes, troubleshooting.
- Settings UI: group-level error aggregation banner above each group; validation client-side (bool/int/enum/url) and backend validation via /v1/settings.
- Test endpoints: /v1/settings/test/{stripe|lago|litellm} for quick connectivity checks.
- Docker: Dockerfile.backend, Dockerfile.frontend, docker-compose.yml, .dockerignore added previously.